
import java.util.Arrays;


/**
 *
 * @author Naimat Khadim
 */
 class Main {
    public static void main(String[] args) {
        int[] array = {5, 2, 7, 1, 3};

        SortContext context = new SortContext();
      System.out.println("Before Sort: " + Arrays.toString(array));
        context.setStrategy(new BubbleSort());
        context.sortArray(array);
        System.out.println("Bubble Sort: " + Arrays.toString(array));

        context.setStrategy(new InsertionSort());
        context.sortArray(array);
        System.out.println("Insertion Sort: " + Arrays.toString(array));

        context.setStrategy(new SelectionSort());
        context.sortArray(array);
        System.out.println("Selection Sort: " + Arrays.toString(array));
    }
}
