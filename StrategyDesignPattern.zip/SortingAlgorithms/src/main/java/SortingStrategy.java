
/*

Case Study: Sorting Algorithms

In this case study, we'll implement different sorting algorithms using the 
Strategy Design Pattern. sWe'll create an application that allows users to 
sort an array of integers using different sorting strategies, such as Bubble
Sort, Insertion Sort, and Selection Sort. The application should provide 
flexibility to switch between different sorting algorithms without modifying 
the existing code.
*/

public interface SortingStrategy {
      void sort(int[] array);
    
}
