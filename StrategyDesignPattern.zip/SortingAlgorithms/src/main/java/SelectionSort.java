
/**
 *
 * @author Naimat Khadim
 */
public class SelectionSort implements SortingStrategy{
    

public void sort(int[] array) {
    int n = array.length;

    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;

        for (int j = i + 1; j < n; j++) {
            if (array[j] < array[minIndex]) {
                minIndex = j;
            }
        }

        // Swap the minimum element with the current element
        int temp = array[minIndex];
        array[minIndex] = array[i];
        array[i] = temp;
    }

    System.out.println("Selection Sort performed.");
}
}
