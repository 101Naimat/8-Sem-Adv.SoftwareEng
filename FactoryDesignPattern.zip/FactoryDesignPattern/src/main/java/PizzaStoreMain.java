/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Naimat Khadim
 */

public class PizzaStoreMain {
    public static void main(String[] args) {
        PizzaStore nyPizzaStore = new NYStylePizzaStore();
        PizzaStore chicagoPizzaStore = new ChicagoStylePizzaStore();

        // Order a cheese pizza from NY style store
        Pizza nyCheesePizza = nyPizzaStore.orderPizza("cheese");

        // Order a pepperoni pizza from Chicago style store
        Pizza chicagoPepperoniPizza = chicagoPizzaStore.orderPizza("pepperoni");
    }
}