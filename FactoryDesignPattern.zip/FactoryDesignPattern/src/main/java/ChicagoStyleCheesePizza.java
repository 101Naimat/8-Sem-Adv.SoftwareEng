


class ChicagoStyleCheesePizza implements Pizza {
    @Override
    public void prepare() {
        System.out.println("Preparing Chicago style cheese pizza");
    }

    @Override
    public void bake() {
        System.out.println("Baking Chicago style cheese pizza");
    }

    @Override
    public void cut() {
        System.out.println("Cutting Chicago style cheese pizza");
    }

    @Override
    public void box() {
        System.out.println("Boxing Chicago style cheese pizza");
    }
}
