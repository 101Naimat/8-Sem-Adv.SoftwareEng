

class NYStylePepperoniPizza implements Pizza {
    @Override
    public void prepare() {
        System.out.println("Preparing NY style pepperoni pizza");
    }

    @Override
    public void bake() {
        System.out.println("Baking NY style pepperoni pizza");
    }

    @Override
    public void cut() {
        System.out.println("Cutting NY style pepperoni pizza");
    }

    @Override
    public void box() {
        System.out.println("Boxing NY style pepperoni pizza");
    }
}
